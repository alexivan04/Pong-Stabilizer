#include "inverseKinematics.h"

// Constante PID (Necesită tuning!)
float Kp = 0.185 , Ki = 0.1, Kd = 0;
float errX_int = 0, lastErrX = 0;
float errY_int = 0, lastErrY = 0;


float calculateArmAngle(int i, float pitch, float roll) {
    // 1. Calcul Cota Z pentru prinderea RJ3
    // h0 = înălțimea neutră (offset)
    // Rp = raza platformei
    float Zi = h0 + Rp * (sin(roll) * cos(servo_gamma[i]) + sin(pitch) * sin(servo_gamma[i]));

    // 2. Coordonate target pentru brațul 2D (L1+L2)
    // Link 3 (L3) coboară vertical din platformă
    float Z_target = Zi - L3;
    float X_offset = abs(Rb - Rp); 

    // 3. Geometrie 2D (Teorema Cosinusului)
    float D = sqrt(sq(X_offset) + sq(Z_target));
    if (D > (L1 + L2)) D = L1 + L2; // Limitare fizică brațe întinse

    float gamma_angle = atan2(Z_target, X_offset);
    float cosBeta = (sq(L1) + sq(D) - sq(L2)) / (2 * L1 * D);
    float beta = acos(constrain(cosBeta, -1.0, 1.0));

    // Unghiul motorului în grade
    return (gamma_angle + beta) * 180.0 / PI;
}

void computeMotorAngles(float targetX, float targetY, volatile float *motorAngles) {
    float errorX = ballData.x - targetX;
    float errorY = ballData.y - targetY;
    // float errorX = ballData.x - targetX;
    // float errorY = ballData.y - targetY;

    // Axa X (Roll)
    errX_int = constrain(errX_int + errorX, -50, 50); // Anti-windup
    float roll = Kp * errorX + Ki * errX_int + Kd * (errorX - lastErrX);
    lastErrX = errorX;

    // Axa Y (Pitch)
    errY_int = constrain(errY_int + errorY, -50, 50);
    float pitch = Kp * errorY + Ki * errY_int + Kd * (errorY - lastErrY);
    lastErrY = errorY;

    // Limitare înclinare platformă (ex: max 10 grade)
    pitch = constrain(pitch, -90.0, 90.0) * PI / 180.0;
    roll = constrain(roll, -90.0, 90.0) * PI / 180.0;

    // --- 2. IK și Actualizare Motoare ---
    float a1 = calculateArmAngle(0, pitch, roll);
    float a2 = calculateArmAngle(1, pitch, roll);
    float a3 = calculateArmAngle(2, pitch, roll);
    float a4 = calculateArmAngle(3, pitch, roll);

    // Trimitem unghiurile către wrapperele tale (care au limitele incluse)
    motorAngles[0] = a1;
    motorAngles[1] = a2;
    motorAngles[2] = a3;
    motorAngles[3] = a4;
}
